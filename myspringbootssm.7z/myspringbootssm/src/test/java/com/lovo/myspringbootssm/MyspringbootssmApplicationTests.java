package com.lovo.myspringbootssm;

import com.demo.dao.IMenuDao;
import com.demo.entity.MenuBean;
import com.demo.myspringbootssm.MyspringbootssmApplication;
import com.demo.service.IMenuService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jms.core.JmsMessagingTemplate;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = {MyspringbootssmApplication.class})
public class MyspringbootssmApplicationTests {
    @Autowired
    private JmsMessagingTemplate jmsMessagingTemplate;
    @Autowired
    private IMenuDao iMenuDao;

    @Autowired
    private IMenuService iMenuService;

    //查询所有
    @Test
    public void findAllMenu() {
        List<MenuBean> list = iMenuDao.findAllMenu();
        for (MenuBean menuBean : list) {
            System.out.println(menuBean);
        }
    }

    //新增
    @Test
    public void insertMenu() {
        MenuBean bean = new MenuBean("123123", "s", "s", "s", "s", "s", "s", "s", "s", "s",
                "s", "s", "s", "s", "s", "s", "s", 0, "1");
        // int i = iMenuService.insertMenu(list);
        int i = iMenuDao.insertMenus(bean);
        System.out.println(i);
    }

    @Test
    public void intsertList() {
        MenuBean bean = new MenuBean("123123", "s", "s", "s", "s", "s", "s", "s", "s", "s",
                "s", "s", "s", "s", "s", "s", "s", 0, "1");
        MenuBean bean3 = new MenuBean("1232", "s", "s", "s", "s", "s", "s", "s", "s", "s",
                "s", "s", "s", "s", "s", "s", "s", 0, "1");
        MenuBean bean2 = new MenuBean("123112313123", "s", "s", "s", "s", "s", "s", "s", "s", "s",
                "s", "s", "s", "s", "s", "s", "s", 0, "1");
        List<MenuBean> list = new ArrayList<>();
        list.add(bean);
        list.add(bean2);
        list.add(bean3);
        int i = iMenuService.insertMenu(list);
        System.out.println(i);
    }

    //删除
    @Test
    public void delete() {
        iMenuDao.deleteMenu(3);
    }
    //条件查询
    @Test
    public void findByMenu() {
        MenuBean menuBean = new MenuBean();
        String s = "s";
        menuBean.setOrgcode(s);
        menuBean.setIsUsed("1");
        List<MenuBean> list = iMenuDao.findByMenuBean(menuBean);
        System.out.println(list);
    }

    //修改
    @Test
    public void updateOne(){
        MenuBean menuBean = new MenuBean();
        menuBean.setId(29);
        List<MenuBean>list = iMenuDao.findByMenuBean(menuBean);
        System.out.println(list);
        for (int i = 0 ; i < list.size();i++){
            menuBean = list.get(i);
            System.out.println(menuBean);
            menuBean.setIsUsed("2");
            iMenuDao.updateOne(menuBean);
        }
    }
}
