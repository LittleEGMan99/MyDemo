package com.demo.myspringbootssm;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@EnableSwagger2 //开启swagger2
@ComponentScan("com.demo")//注解扫描包
@MapperScan("com.demo.mapper") //注解扫描mapper包
@EnableTransactionManagement //开启事务管理
@SpringBootApplication
@EnableScheduling //开启调度器
public class MyspringbootssmApplication {

    public static void main(String[] args) {
        SpringApplication.run(MyspringbootssmApplication.class, args);
    }

}
