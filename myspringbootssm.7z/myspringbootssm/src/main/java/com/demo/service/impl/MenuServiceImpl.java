package com.demo.service.impl;

import com.demo.dao.IMenuDao;
import com.demo.entity.MenuBean;
import com.demo.service.IMenuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MenuServiceImpl implements IMenuService {

    @Autowired
    private IMenuDao menuDao;

    @Override
    public List<MenuBean> findAll() {
        return menuDao.findAllMenu();
    }

    @Override
    public void deleteMenuById(int id) {
        menuDao.deleteMenu(id);
    }

    @Override
    public int insertMenu(List<MenuBean>list) {
        int result = 0 ;
        for (MenuBean menu : list) {
            System.out.println(menu);
            menuDao.insertMenus(menu);
            result ++;
        }
        return result;
    }
}
