package com.demo.service;

import com.demo.entity.MenuBean;

import java.util.List;

public interface IMenuService {

    public List<MenuBean> findAll();

    public void deleteMenuById(int id);

    public int insertMenu(List<MenuBean>list);
}
