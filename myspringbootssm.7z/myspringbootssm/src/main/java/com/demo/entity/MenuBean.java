package com.demo.entity;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class MenuBean {
    public MenuBean(){}
    //菜单主键
    private String menu_code;
    //菜单布放方式
    private String lay_flag;
    //机构号
    private String orgcode;
    //业务类型不可用
    private String disable;
    //白名单业务类型
    private String white_biz;
    //设备类型
    private String devicetype;
    //菜单ID
    private String menu_id;
    //菜单名称
    private String name;
    //菜单地址
    private String url;
    //菜单参数
    private String parames;
    //菜单样式
    private String style;
    //菜单图片
    private String icon;
    //显示序号
    private String disp_no;
    //父菜单
    private String sup_menu;
    //菜单描述
    private String menu_desc;
    //菜单英文名
    private String name_en;
    //菜单英文描述
    private String menu_desc_en;

    private int id;

    private String isUsed;


}
