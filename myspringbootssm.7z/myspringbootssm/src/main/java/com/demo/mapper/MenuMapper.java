package com.demo.mapper;

import com.demo.entity.MenuBean;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MenuMapper {

    List<MenuBean> findAllMenu();


    int insertMenus(MenuBean menuBean);


    void deleteMenu(@Param("id") int id);

    List<MenuBean> findByMenuBean(MenuBean menuBean);

    void updateOne(MenuBean menuBean);
}
