package com.demo.dao;

import com.demo.entity.MenuBean;

import java.util.List;

public interface IMenuDao {
     //查询全表
     List<MenuBean> findAllMenu();
     //单条插入
     int insertMenus(MenuBean menuBean);
     //根据ID删除
     void deleteMenu(int id);
     //动态条件查询
     List<MenuBean> findByMenuBean(MenuBean menuBean);
     //修改
     void updateOne(MenuBean menuBean);
}
