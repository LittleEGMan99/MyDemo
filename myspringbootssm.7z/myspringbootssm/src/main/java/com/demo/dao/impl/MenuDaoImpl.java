package com.demo.dao.impl;

import com.demo.dao.IMenuDao;
import com.demo.entity.MenuBean;
import com.demo.mapper.MenuMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class MenuDaoImpl implements IMenuDao {
    @Autowired
    private MenuMapper menuMapper;

    @Override
    public List<MenuBean> findAllMenu() {
        return menuMapper.findAllMenu();
    }

    @Override
    public int insertMenus(MenuBean menuBean) {
        return menuMapper.insertMenus(menuBean);
    }

    @Override
    public void deleteMenu(int id) {
        menuMapper.deleteMenu(id);
    }

    @Override
    public List<MenuBean> findByMenuBean(MenuBean menuBean) {
        return menuMapper.findByMenuBean(menuBean);
    }

    @Override
    public void updateOne(MenuBean menuBean) {
        menuMapper.updateOne(menuBean);
    }
}
