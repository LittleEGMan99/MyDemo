package com.demo.controller;

import com.demo.entity.MenuBean;
import com.demo.service.IMenuService;
import com.demo.util.ResponseData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 用户页面控制器类
 */
@RestController
@RequestMapping("/html/")
public class MenuController {
    @Autowired
    private IMenuService menuService;

    private Logger logger = LoggerFactory.getLogger(MenuController.class);

    @RequestMapping(value = "insertMenu",method = RequestMethod.GET)
    public ResponseData login(List<MenuBean>list){
        int result = menuService.insertMenu(list);
        ResponseData responseData = new ResponseData();
        responseData.setMessage("成功提交:"+result+"条记录");
        return responseData;
    }
}
