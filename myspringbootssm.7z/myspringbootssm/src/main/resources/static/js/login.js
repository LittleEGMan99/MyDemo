$(function(){
    $("#login").click(function () {
        $.getJSON("mylogin",{
            username:$("#username").val(),
            password:$("#password").val()
        },getAjaxData)
    })

    function getAjaxData(data) {
        if (data.message == "ok") {
            window.location.href="../html/loginok.html";
        } else {
            window.location.href="../html/login.html";
        }
    }
})